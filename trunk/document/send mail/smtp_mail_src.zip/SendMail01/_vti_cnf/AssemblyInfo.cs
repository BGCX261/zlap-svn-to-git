vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Oct 2002 07:17:48 -0000
vti_extenderversion:SR|5.0.2.2623
vti_lineageid:SR|{CACC61A0-6373-4BE2-8AE3-7528FDBC62FE}
vti_cacheddtm:TX|26 Oct 2002 07:17:48 -0000
vti_filesize:IR|2894
vti_backlinkinfo:VX|
