vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Oct 2002 07:17:48 -0000
vti_extenderversion:SR|5.0.2.2623
vti_lineageid:SR|{011BFEFD-0014-4E60-AB6B-A386886EB1F7}
vti_cacheddtm:TX|26 Oct 2002 07:17:48 -0000
vti_filesize:IR|1108
vti_backlinkinfo:VX|
