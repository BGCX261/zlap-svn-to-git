vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Oct 2002 07:17:47 -0000
vti_extenderversion:SR|5.0.2.2623
vti_lineageid:SR|{00FB3977-49A6-4B0C-A241-D10D731FF83F}
vti_cacheddtm:TX|26 Oct 2002 07:17:47 -0000
vti_filesize:IR|1289
vti_backlinkinfo:VX|
