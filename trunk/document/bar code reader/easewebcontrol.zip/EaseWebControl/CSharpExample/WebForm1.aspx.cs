using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using EaseSoftBarcode;

namespace CSharpDemo
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class Barcode : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DropDownList DropDownList_Symbology;
		protected System.Web.UI.WebControls.DropDownList DropDownList_Fontname;
		protected System.Web.UI.WebControls.TextBox TextBox_Text;
		protected System.Web.UI.WebControls.TextBox TextBox_Fontsize;
		protected System.Web.UI.WebControls.TextBox TextBox_Height;
		protected System.Web.UI.WebControls.TextBox TextBox_Ratio;
		protected System.Web.UI.WebControls.TextBox TextBox_Width;
		protected System.Web.UI.WebControls.DropDownList DropDownList_Checkdigit;
		protected System.Web.UI.WebControls.TextBox TextBox_Barheight;
		protected System.Web.UI.WebControls.TextBox TextBox_Topmargin;
		protected System.Web.UI.WebControls.TextBox TextBox_Narrowbarwidth;
		protected System.Web.UI.WebControls.TextBox TextBox_Leftmargin;
		protected System.Web.UI.WebControls.DropDownList DropDownList_Forecolor;
		protected System.Web.UI.WebControls.TextBox TextBox_Textmargin;
		protected System.Web.UI.WebControls.DropDownList DropDownList_Backcolor;
		protected System.Web.UI.WebControls.DropDownList DropDownList_Addcheckdigittotext;
		protected System.Web.UI.WebControls.DropDownList DropDownList_Showtext;
		protected EaseSoftBarcode.EaseWebControl EaseWebControl1;
		protected System.Web.UI.WebControls.TextBox TextBox_Image;
		protected System.Web.UI.WebControls.Button Button_SaveImage;
		protected System.Web.UI.WebControls.Button Button_Createbarcode;
		protected EaseSoftBarcode.Symbology symbology ;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Button_SaveImage.Click += new System.EventHandler(this.Button_SaveImage_Click);
			this.Button_Createbarcode.Click += new System.EventHandler(this.Button_Createbarcode_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void SetBarcodeProperties(ref EaseSoftBarcode.EaseWebControl easeWebControl)
		{
			int fontsize=12;			
			switch( DropDownList_Symbology.SelectedIndex)
			{
				case 0: symbology= EaseSoftBarcode.Symbology.Code39;break;
				case 1: symbology= EaseSoftBarcode.Symbology.Code39ASCII;break;
				case 2: symbology= EaseSoftBarcode.Symbology.Code93;break;
				case 3: symbology= EaseSoftBarcode.Symbology.UPCA;break;
				case 4: symbology= EaseSoftBarcode.Symbology.EAN13;break;
				case 5: symbology= EaseSoftBarcode.Symbology.EAN8;break;
				case 6: symbology= EaseSoftBarcode.Symbology.UPCE;break;
				case 7: symbology= EaseSoftBarcode.Symbology.BookLand;break;
				case 8: symbology= EaseSoftBarcode.Symbology.Code128;break;
				case 9: symbology= EaseSoftBarcode.Symbology.UCC128;break;
				case 10: symbology= EaseSoftBarcode.Symbology.Code25;break;
				case 11: symbology= EaseSoftBarcode.Symbology.I25;break;
				case 12: symbology= EaseSoftBarcode.Symbology.Code11;break;
				case 13: symbology= EaseSoftBarcode.Symbology.Codabar;break;
				case 14: symbology= EaseSoftBarcode.Symbology.MSI;break;
				case 15: symbology= EaseSoftBarcode.Symbology.PDF417;break;
				case 16: symbology= EaseSoftBarcode.Symbology.DataMatrix;break;
				default: symbology= EaseSoftBarcode.Symbology.Code39;break;
			}
			easeWebControl.SymbologyID= symbology;
			easeWebControl.TextToEncode= TextBox_Text.Text;
		 
			try
			{
				fontsize= Convert.ToInt32(TextBox_Fontsize.Text);
				easeWebControl.Font=new Font(DropDownList_Fontname.SelectedItem.Text,fontsize);
				easeWebControl.Ratio=Convert.ToInt32(TextBox_Ratio.Text);
				easeWebControl.Height=Convert.ToInt32(TextBox_Height.Text);
				easeWebControl.Width=Convert.ToInt32(TextBox_Width.Text);
				easeWebControl.BarHeight=Convert.ToInt32(TextBox_Barheight.Text);
				easeWebControl.NarrowBarWidth=Convert.ToInt32(TextBox_Narrowbarwidth.Text);
				easeWebControl.TopMargin=Convert.ToInt32(TextBox_Topmargin.Text);
				easeWebControl.LeftMargin=Convert.ToInt32(TextBox_Leftmargin.Text);
				easeWebControl.TextMargin=Convert.ToInt32(TextBox_Textmargin.Text);
			}
			catch
			{};

			easeWebControl.ForeColor= Color.FromName(DropDownList_Forecolor.SelectedItem.Text);
			easeWebControl.BackColor= Color.FromName(DropDownList_Backcolor.SelectedItem.Text);
			easeWebControl.ShowText= (DropDownList_Showtext.SelectedIndex==0);
			easeWebControl.AddCheckDigit=(DropDownList_Checkdigit.SelectedIndex==0);
			easeWebControl.AddCheckDigitToText=(DropDownList_Addcheckdigittotext.SelectedIndex==0);

		}

		private void Button_Createbarcode_Click(object sender, System.EventArgs e)
		{
			SetBarcodeProperties(ref EaseWebControl1);
		}

		private void Button_SaveImage_Click(object sender, System.EventArgs e)
		{
          SetBarcodeProperties(ref EaseWebControl1);		
		  EaseWebControl1.ResolutionDPI = 300;
		  EaseWebControl1.Picture.Save( TextBox_Image.Text,System.Drawing.Imaging.ImageFormat.Bmp);
		}
	}
}
