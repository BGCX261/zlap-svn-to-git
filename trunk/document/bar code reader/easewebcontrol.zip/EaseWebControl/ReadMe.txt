
Readme File for EaseSoft Barcode ASP.NET Web Server control And .Net Windows Forms Control V3.5
============================================================================================================

The readme file contains the technical information related to the use of the Demo version of the 
EaseSoft Barcode .Net and Asp.net controls.Please read this section thoroughly so that you will understand 
the limitations of this demo and how it may be used with other Windows programs.

Contents:
1. Introduction.
2. Installation.
3. Test EaseSoft Barcode .Net controls
4. Limitations of the Demo version.
5. Requirement
6. How to purchase a fully working version of the EaseSoft Barcode Control.

Introduction
============================================================================================================
Thank you for evaluating the EaseSoft Bar Code .Net and ASP.NET Controls!

Welcome to EaseSoft Barcode  ControlS! EaseSoft Barcode Controls have .Net Windows Forms Controls
and ASP.NET Web Server Controls.EaseSoft Barcode Controls support most barcode symbologies including
Code 39, Code 39 full asscii, Code 128, UCC/EAN-128,Industrial 2 of 5 Planet, Interleaved 2 of 5, Codabar,
UPC-A,UPC-E, EAN 13, EAN 8, BOOKLAND,MSI, Code 11, Code 93, Postnet,PDF417, DataMatrix.

1. ASP.NET Web Server Control contains the following files: EaseWebControl.dll, Web.config
2. Windows .Net Forms Control contains this file: EaseWinControl.dll
3. There are visual studio 2002.net, visual studio 2003.net and visual studio 2005 compiled version 

INSTALLATION
============================================================================================================


1. Register EaseSoft Barcode .Net and ASP.NET Control 
   Register EaseSoft Barcode .Net and ASP.NET Control in visual studio.net: 

   1) Open your solution or application and display the form that you want to add the barcode to. 
      Choose View - Toolbox to display the Toolbox. 
   2) Right click on the Toolbox and choose Customize Toolbox. Choose the .NET Framework Components.
       Choose Browse and select the  EaseWebControl.dll( for ASP.NET Control) or EaseWinControl.dll
      (for .Net Windows Forms Control).
   3)  After added the controls to the Toolbox, you can use it just like other controls. 


2. Configuring the Web.Config file for ASP.NET Web Server Control
   EaseSoft Barcode ASP.NET Web ServerControls use its internal HttpHandler to transfer barcode images 
   directly to the client without any temporary files.It is the most efficient method to generate the 
   barcodes dynamically. You need to add httpHandlers tag to Web.Config file, The Web.Config file should
   look like this: 
   
    <?xml version="1.0" encoding="utf-8" ?>
    <configuration>
       <system.web>
          <httpHandlers>
             <add verb="*" path="ImageService.axd" type="EaseSoftBarcode.ImageService,EaseWebControl"/> 
          </httpHandlers>


Test EaseSoft Barcode .Net and ASP.NET controls
============================================================================================================
 1. Test ASP.NET Web Server Control

   1) create a vitual directory(for example C:\Inetpub\wwwroot\EaseSoftBarcodeDemo) in your IIS server Manager.
   2) Copy Demo.aspx,web.config to this directory
   3) Copy the EaseWebControl.dll to the sub folder "bin" folder of the directory you created. 
   4) Then enter http://localhost/EaseSoftBarcodeDemo/Demo.aspx in your browser.  
 
 2. Test .Net Windows Forms Control
    Run demo.exe to experience the rich features of EaseSoft .Net Windows Forms Control.

Both ASP.NET Web Server Control and .Net Windows Forms Control include C# and VB.Net example project. If the .Net
Controls reference not in the correct position, You need to add EaseWebControl.dll or EaseWinControl.dll to the
reference in the example solution.

Our Online Barcode .Net Controls demo: http://www.easesoft.net/Barcode_Online_Generator.aspx


Limitations of the Demo version:
============================================================================================================
The demo version of the EaseSoft Barcode Control is a fully working version of the control except that 
it has the following limitations:

the bottomcomment property always is set to "EaseSoft Copyright".


Requirement
============================================================================================================
Microsoft Windows 98, Windows Me, Windows NT 4.0 with Service Pack 6a or higher, Windows 2000, Windows XP, 
or Windows .NET Server. Microsoft Internet Explorer 5.01 or later. Microsoft .net framework 1.1 or later

If you need .net framework 1.0 version,please contact us via info@easesoft.net


How to purchase?
============================================================================================================
We recommend you order online through this URL:
Buy: http://www.easesoft.net/Order.html
web: www.easesoft.net
email: sales@easesoft.net

Contact
============================================================================================================
Any comment will be appreciated.

info@easesoft.net

