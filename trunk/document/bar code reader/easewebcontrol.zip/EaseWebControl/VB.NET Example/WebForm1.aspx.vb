Imports System.Data
Imports System.Data.OleDb
Imports System.Data.SqlClient


Public Class WebForm1
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents EaseWebControl1 As EaseSoftBarcode.EaseWebControl
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim Table As DataTable
        Dim Row As DataRow
        Dim DS As DataSet
        Dim MyConnection As OleDbConnection
        Dim MyAdapter As OleDbDataAdapter
        Dim Querry As String
        Dim strConnectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & _
    "C:\Inetpub\wwwroot\VBDEMO\TestDb.mdb"
        MyConnection = New OleDbConnection(strConnectionString)
        MyConnection.Open()
        Querry = "select * from TestTable where EmpNbr=@EmpID"
        MyAdapter = New OleDbDataAdapter(Querry, MyConnection)
        MyAdapter.SelectCommand.Parameters.Add(New OleDbParameter("@EmpID", OleDbType.BSTR, 12))
        MyAdapter.SelectCommand.Parameters("@EmpID").Value = TextBox1.Text.Trim

        DS = New DataSet
        MyAdapter.Fill(DS, "TestTable")
        Table = DS.Tables("TestTable")
        If Table.Rows.Count > 0 Then
            Label1.Text = ""
            Row = Table.Rows(0)
            EaseWebControl1.SymbologyID = EaseSoftBarcode.Symbology.Code39ASCII
            EaseWebControl1.Visible = True
            EaseWebControl1.TextToEncode = Row.Item("EmpNbr")
           
        Else
            Label1.Text = "Can't Find The Record!"
            EaseWebControl1.Visible = False
           
        End If



        MyConnection.Close()


    End Sub
End Class
