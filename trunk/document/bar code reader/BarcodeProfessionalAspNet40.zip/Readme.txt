Barcode Professional 4.0 for ASP.NET
------------------------------------

Thank you for downloading Barcode Professional 4.0 for ASP.NET

Before beginning to install this software, please uninstall any older version from your machine.
To install this software, run the installer included into the download package and follow its screen instructions.

Thanks for your time.

The Neodynamic Team
http://www.neodynamic.com
