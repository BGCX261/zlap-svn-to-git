Windows Forms Control Code 128 Demo Version

This is the demo version of the Windows Forms Control Code 128 for Windows XP/Vista.

*** What are the system requirements ***

Visual Studio 2005 or Visual Sudio Epress 2005 or any other .net 2.0 compatible environment.

*** What are the restrictions of the demo version? ***

In the demo version the software will print the word DEMO near the barcode. However, all barcodes will still scan perfectly with a standard barcode reader.

*** Where can I get more information on how to use the software? ***

In the ZIP archive locate the folder "Doc". It contains the manual in HTML form.

*** How do I buy the software? ***

Visit our online store directly at:

http://www.pro-barcode.com/buy-developer.html

Upon completion of your order you'll receive an email with a keycode to unlock the demo. Our store works real time 24*7 so usually this only takes a few minutes. 

*** How do I uninstall the demo? ***

Simply run setup.exe again and, if prompted, select: Remove or Uninstall. 

(c) Wolf Software. All rights reserved.

http://www.pro-barcode.com
