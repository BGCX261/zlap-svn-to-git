ExportData class library (V 1.0.0.0)
=================================
By Rama Krishna - 2004

How to run the test solution
-----------------------
After extracting the zip file, right-click the ExportDemo_CSharpNet folder and select properties.
Select WEB SHARING tab and select SHARE this folder (which will be ExportDemo_CSharpNet). 

Once the WEB SHARE is created then open the solution file in Visual Studio 2003.

